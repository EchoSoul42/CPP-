#include<iostream>
using namespace std;
 
void swap (int & ,int &);
int main()
{
    int a =10;
    int b= 20;
    
    cout<<"before swapping a="<<a<<"b= "<<b<<endl;
    
    swap(a,b);
    cout<<"before swapping a="<<a<<"b= "<<b<<endl;
}
void swap(int &p ,int &q)
{
 int temp;
 temp=p;
 p=q;
 q=temp;

}