#include<iostream>
using namespace std;

class complex {
    int real,imag;

    public:
    complex();
    complex(int,int);
    
    void display()const;
    void setReal(int);
    int getReal()const;

};
void complex::setReal(int r){
    real=r;
}
int  complex::getReal()const{
    return real;
}

complex::complex(){
    cout<<"default"<<endl;
    real=1;
    imag=2;
}
complex::complex(int r,int i){
        cout<<"Paramaterized constructor"<<endl;
    real=r;
    imag=i;
    
}
void complex::display()const{
    cout<<"complex no is"<<real<<"+"<<imag<<"i"<<endl;
}
int main(){
  const complex c1(6,7);
  cout<<"real part"<<c1.getReal();
  complex c2(9,8);
  c2.setReal(10);
  cout<<"real part"<<c2.getReal();
  
}