#include<iostream>
using namespace std;

int main(){
    char a,b,symbol;
    int sum;
    cout<<"accept a and b character:"<<endl;
    cin>>a>>b;
    symbol=a+b;
    sum=a+b;

    cout<<"sum of a and b:"<<sum<<endl;
    cout<<"showing symbol after sum of a and b:"<<symbol<<endl;
}