#include<iostream>
using namespace std;

class cdate
{
    int dd,mm,yy;
    public:
    void accept();
    void display();
    void setDd(int);
    int getDd();

};
void cdate:: accept()
{
    cout<<"enter date , month & year"<<endl;
    cin>>dd>>mm>>yy;
    
}
void cdate:: display()
{
    cout<<"date, month & year are="<<dd<<"/"<<mm<<"/"<<yy<<endl;
   
}
void cdate:: setDd(int d)
{
	dd=d;
	
}
int cdate::getDd(){
	return dd;
}
int main()
{
	
cdate c1;
c1.accept();
c1.display();
c1.setDd(10);
c1.getDd();
cout<<"The day is"<<c1.getDd();


}

