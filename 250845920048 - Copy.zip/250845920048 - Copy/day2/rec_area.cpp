#include<iostream>
using namespace std;

int main(){
    int a,b,rec;
    cout<<"accept a and b:"<<endl;
    cin>>a>>b;
    rec=a*b;
    cout<<"sum of a and b:"<<rec<<endl;
}