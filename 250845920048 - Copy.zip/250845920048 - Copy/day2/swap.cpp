#include<iostream>
using namespace std;

int main(){
    int a,b,temp;
    cout<<"accept a and b:"<<endl;
    cin>>a>>b;
    temp=a;
    b=a;
    a=temp;

    cout<<"swap of a and b:"<<temp<<endl;
}