#include<iostream>
using namespace std;

int main(){
    int a,b,sum;
    cout<<"accept a and b:"<<endl;
    cin>>a>>b;
    sum=a+b;
}