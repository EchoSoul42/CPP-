#include <iostream>

using namespace std;

int main() {
    double base, exponent, result=1;

    cout << "Enter base: ";
    cin >> base;
    cout << "Enter exponent: ";
    cin >> exponent;

     for (int i = 0; i < exponent; ++i) {
        result =result * base; 
    }

    cout << base << "^" << exponent << " = " << result << endl;

    
}
