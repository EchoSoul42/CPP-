 #include<iostream>

 using namespace std;
 int main()
 {

 
 int a=10;
 int &a_new= a;
 cout<<"value of a_new is ="<<a_new<<"and a is="<<a<<endl;
 cout<<"address of a_new is ="<<&a_new<<"and a is"<<&a<<endl;
 }
