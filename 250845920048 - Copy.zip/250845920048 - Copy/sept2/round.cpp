#include<iostream>
#include<math.h>
using namespace std;

int main(){
    float x=7.2;
    cout<<"floor value is:"<<floor(x)<<endl;
    cout<<"round value is:"<<round(x)<<endl;
    cout<<"ceil value is:"<<ceil(x);
}