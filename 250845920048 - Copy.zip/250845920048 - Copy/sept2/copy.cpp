#include<iostream>
#include<string.h>
using namespace std;

class sample

{
    int id;
    public:
    void init(int x){
        id=x;
    }
    void display(){
        cout<<"display"<<id<<endl;
    }
};
int main(){
    sample s1;
    s1.init(10);
    s1.display();

    sample s2(s1);
    s2.display();
    
}
	