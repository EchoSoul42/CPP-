#include<iostream>
using namespace std;

class cdate
{
    int dd,mm,yy;
    public:
    
     cdate(int d,int m,int y){
         dd=d;
         mm=m;
         yy=y;

     }
     void show(){
        cout<<dd<<"/"<<mm<<"/"<<yy<<endl;
     }
     cdate(cdate& s)
     {
        this->dd=s.dd;
        this->mm=s.mm;
        this->yy=s.yy;
        cout<<"copy called"<<endl;
     }
     

};
int main(){
    cdate c1(11,12,2025);
    c1.show();
    cdate c2(c1);
    c2.show();

}