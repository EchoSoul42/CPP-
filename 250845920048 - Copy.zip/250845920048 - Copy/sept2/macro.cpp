#include<iostream>
using namespace std;

#define MACRO(a, b) (a<b)?a:b

int main(){
    cout<<"macro(100,1000)";
    int k=MACRO(100,1000);
    cout<<k<<endl;
    cout<<"macro(100,20)";
    int l=MACRO(100,20);
    cout<<l<<endl;
}