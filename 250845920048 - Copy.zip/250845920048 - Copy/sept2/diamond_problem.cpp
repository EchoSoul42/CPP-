#include<iostream>
using namespace std;

class base{
    public:
    void fun(){
      cout<<"base class"<<endl;
    }
};
class p1:public base{
    public:
       void fun(){
        cout<<"p1 class"<<endl;
       }
};
class p2:public base{
    public:
       void fun(){
        cout<<"p2 class"<<endl;
       }
};
class child :public p1 ,p2 {
    public:
       void fun(){
        cout<<"child class"<<endl;
       }
};
int main(){
    child c1;
    c1.base::fun();
}