#include <iostream>
#include <string.h>
using namespace std;

class string1
{
    int len;
    char *ptr;

public:
    string1(char *);
    ~string1();
    void display();
    string1(string1 &);
};
void string1::display()
{
    cout << "length is:" << len << endl;
    cout << "string is:" << ptr << endl;
}
string1::string1(char *sptr)
{
    len = strlen(sptr);
    ptr = new char(len + 1);
    strcpy(ptr, sptr);
}
string1::~string1(){
    cout<<"destructor is called:";
    if(ptr){
        delete[] ptr;
    }
}
string1:: string1(string1 & c){
    this->len=c.len;
	this->ptr=new char[this->len+1];
	strcpy(this->ptr,c.ptr);
}
int main()
{
    string1 s1("abc");
    s1.display();
    string1 s2(s1);
    s2.display();
    s1.display();}