#include<iostream>
using namespace std;
#include<string.h>

void  user_strcpy(char*,char*);
int main(){
    char str1[20];
    char str2[50];
    cout<<"accept string:"<<endl;
    cin>>str1;

     user_strcpy(str2,str1);
    cout<<"copied string:"<<str2;



}
void user_strcpy(char*s2,char*s1){
    while(*s1!='\0'){
        *s2=*s1;
        *s2++;
        *s1++;
    }
    *s2='\0';

}


