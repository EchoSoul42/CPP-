#include<iostream>
using namespace std;
int main()
{
    int num,i;
   
    cout<<"enter value"<<endl;
    cin>>num;

    for (i = 2; i < num; i++)
    {   
        if ( num % i == 0)
        {
             cout<<"not prime"; 
             break;
        }
        else{
             cout<<"prime";
             break;
        }
        
    }
    
}