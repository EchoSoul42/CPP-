#include<iostream>
using namespace std;

int main(){
    int num;
    int OG;
    int i;
    int rem,sum=0;

 
    cout<<"enter no"<<endl;
    cin>>num;
    OG=num;

    while(num != 0)
    {
        rem=(num%10);
        sum=sum+rem*rem*rem;
       num= num/10;
        
    }

    if(sum==OG){
        cout<<"Armstrong"<<endl;
    }
    else{
        cout<<"not armstrong"<<endl;
    }
    
}

     