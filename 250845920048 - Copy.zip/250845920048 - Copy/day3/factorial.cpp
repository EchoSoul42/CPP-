#include<iostream>

using namespace std;

int main(){
    int num;
    long long factorial=1;
    int i;

    cout<<"accept the number from user:"<<endl;
    cin>>num;

    for(i=1;i<=num;i++){
        factorial =factorial*i;
    
    }
    cout<<"factorial  ="<<factorial<<endl;


}