#include<iostream>
using namespace std;

void display();
int x=10;
int main(){
    cout<<x<<endl;  //10
    x++;

    display();
    cout<<x<<endl; //11
}
void display(){
    cout<<x<<endl; //11
    int x=0;
    cout<<x<<endl; //0
    x=3;
    cout<<x<<endl; //3
}