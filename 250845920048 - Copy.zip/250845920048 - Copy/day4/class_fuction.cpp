#include<iostream>
#include<string.h>
using namespace std;
void student(int,char*);
class college
{
    public:
    int id;
    char name[10];
    static char clg[20];

    void student(int i,char* a )
    {
      id=i;
      strcpy(name,a);
    }
    void display()    
        {    
            cout<<id<<"   "<<name<<"   "<<clg<<endl;   
        }  
};
 char college::clg[20]={"xyz"};
 int main(){  
   college s1;
   s1.student(11,"name");
   s1.display();
 }

