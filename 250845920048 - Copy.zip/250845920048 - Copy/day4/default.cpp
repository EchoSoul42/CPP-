#include<iostream>
using namespace std;

void add(int=1,int=2,int=3,int=0);

    


int main(){
    add();
    add(2);
    add(2,4);

   
}
void add(int a,int b,int c,int d){
    cout<<a<<b<<c<<d<<endl;
}