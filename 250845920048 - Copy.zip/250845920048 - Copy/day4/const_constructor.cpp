#include<iostream>
using namespace std;
class student{
    int rollno;
    char name;

    public:
    student();
    student(int,char);
    student::student(){
    int rollno=10;
    char name='a';
    cout<<"roll="<<rollno<<"name"<<name<<endl;

    };
    student::student(int r, char n){
    int rollno=r;
    char name=n;
    cout<<"roll="<<rollno<<"name"<<name<<endl;
    };


};


int main(){
    student s1 ();
    student s2(2,'z');

}