#include<iostream>
using namespace std;
#include<string.h>

void  user_stringrev(char*,char*);
int main(){
    char str1[20];
    char str2[20];
    int i;
    cout<<"accept string:"<<endl;
    cin>>str1;
    

    int n=strlen(str1);

   for(i=0;i<n;i++)
   {
    str2[i]=str1[n-1-i];
   }
   str2[n]='\0';
   cout<<str2<<endl;
}


