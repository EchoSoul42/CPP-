#include<iostream>

using namespace std;

int main(){
    int n=0,m=1,fib,i,no;
    cout<<"enter no";
    cin>>no;
    for (i = 0; i <=no ; i++)
    {
        fib=m+n;
        n=m;
        m=fib;
        cout<<fib<<endl;
    }
    

}