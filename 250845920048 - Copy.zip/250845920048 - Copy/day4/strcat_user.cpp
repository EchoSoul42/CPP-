#include<iostream>
using namespace std;
#include<string.h>

void  user_strcpy(char*,char*);
int main(){
    char str1[20];
    char str2[50];
    cout<<"accept string 1:"<<endl;
    cin.getline(str1,20);
    cout<<"accept string 2:"<<endl;
    cin.getline(str2,50);

    user_strcpy(str2,str1);
    cout<<"Concat string:"<<str1;
}
void user_strcpy(char*s2,char*s1){
   while(*s1!='\0')
   {
       *s1++;
   }
    while(*s2!='\0'){                      ///not done
        
        *s1=*s2;
        *s2++;
        *s1++;
    }
    *s2='\0';
}


