#include<iostream>

using namespace std;

class student{
    int marks=78;
    public:
    int get_marks(){
        return marks;
    }
    void display(){
        cout<<"marks is:"<<marks<<endl;
    }


};
class sem1:public student{
    int sem2_marks=89;
    public:
    int get_sem2_marks(){
        return sem2_marks;
    }
   void display(){
        cout<<sem2_marks+get_marks()<<endl;
    }
};
class sem2:public sem1{
    int sem3_marks=45;
    public:
    void show(){
        cout<<get_marks()+get_sem2_marks()+sem3_marks<<endl;
    }
};
int main(){
sem2 s1;
s1.display();
s1.show();

}