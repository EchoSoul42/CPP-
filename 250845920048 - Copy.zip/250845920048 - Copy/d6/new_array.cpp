#include <iostream>
using namespace std;

int main()
{
    int i;
    int n;
    cout<<"enter length of array to be "<<endl;
    cin>>n;
    int* ptr =new int;
    cout<<"enter element of array "<<endl;
    for(i=1;i<=n;i++)
    {
       cin>>*(ptr+i);
    }
   for(i=1;i<=n;i++)
    {
       cout<<*(ptr+i);
    }
    delete ptr;

}