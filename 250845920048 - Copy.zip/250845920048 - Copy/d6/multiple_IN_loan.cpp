#include<iostream>
using namespace std;

class loan{
  s_loan
}