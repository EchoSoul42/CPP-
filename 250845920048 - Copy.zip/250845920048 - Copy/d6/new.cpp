#include<iostream>
using namespace std;

int main()
{
    int a;
    cout<<"enter no to store i heap "<<endl;
    cin>>a;
   
    int *ptr = new int(a);
    cout<<*ptr<<endl;
    delete ptr;
}
