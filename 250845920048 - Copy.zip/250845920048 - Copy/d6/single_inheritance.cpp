#include<iostream>
using namespace std;
 class account{
    int bonus =2000;
    public:
    int get_bonus(){
       
        return bonus;
    }
    void show_parent(){
         cout<<"bonus is "<<bonus<<endl;
    }
 };
 class employee: public account{
    int salary=1000;
    public:
    void show_salary(){
         int sal;
         cout<<salary + get_bonus()<<endl;
        
    }

 };
 int main()
 {
    employee a1;
    a1.show_salary();
    a1.show_parent();
   

 }