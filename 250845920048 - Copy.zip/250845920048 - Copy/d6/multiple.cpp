#include<iostream>
using namespace std;

class Account{
    int a=1000;

    public:
    int get_a(){
        return a;
    }
    void display(){
        cout<<"a ="<<a<<endl;
    }
};

class child1:public Account{
    int b=200;

    public:
    int get_b(){
        return b;
    }
    void display(){
        cout<<get_a()+get_b()<<endl;
    }


};

class child2:public Account{
    int c=234;
    public:
    int get_c(){
        return c;
    }
   void display(){
   cout<<get_a()+get_c()<<endl;

    
   }
};

int main(){
    child1 a1;
    a1.display();

}