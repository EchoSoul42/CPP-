#include <iostream>

using namespace std;

int main() {
    int rows = 5;

    for (int i = 0; i < rows; ++i) {
        for (int j = 1; j <= rows - i; ++j) {
            cout << "  ";
        }
        
        int number = 1;
        for (int j = 0; j <= i; ++j) {
            cout << number << "   ";
            number = number * (i - j) / (j + 1);
        }
        cout << endl;
    }
    return 0;
}