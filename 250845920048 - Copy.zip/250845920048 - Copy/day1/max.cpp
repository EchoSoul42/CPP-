#include<iostream>
using namespace std;

int main()
{
int a[5]={};
int max;
int i;
cout<<"enter values";
for(i=1;i<=4;i++)
{
	cin>>a[i];
}

max=a[0];
for(i=1;i<=4;i++)
{
	if (max<a[i])
	max=a[i];
}
	cout<<"max number is="<<max;
	
}
