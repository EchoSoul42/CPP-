#include<iostream>
using namespace std;

int main()
{
	int a[3][3];
	int i;
	int j;

	cout<<"enter Values"<<endl;
	for(i=0 ;i<=2; i++)
	{
		for(j=0 ;j<=2; j++)
		{
			cin>>*(*(a+i)+j);
		}
		
		
	}
	cout<<"values are"<<endl;
	for(i=0 ;i<=2; i++)
	{
			for(j=0 ;j<=2; j++)
		{
			cout<<*(*(a+i)+j);
		}
		
	}
	cout<<endl;
}
