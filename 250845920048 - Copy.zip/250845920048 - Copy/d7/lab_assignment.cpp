#include<iostream>
using namespace std;


 class student
 {
   
   int roll;
   char dob[10];
   char name;
   int marks;
   public:
   void get_data();
   void sort();
};
void student ::get_data(){
    
      cin>> roll;
      cin>> dob;
      cin>> name;
      cin>> marks;
   };
   student student ::sort(student i[],k){
    
   }

int main(){
    int n,i;
    cout<<"enter no of students";
    cin>>n;
    student a[i];
    for ( i = 0; i < n; i++)
    {
        a[i].get_data();
    }
     a->sort(a,n);   
     

}


