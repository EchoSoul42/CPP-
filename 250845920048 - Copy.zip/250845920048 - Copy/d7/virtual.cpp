#include <iostream>
using namespace std;

class employee
{
    int id;

public:
    employee();
    employee(int);
    virtual void display();
    virtual int salary()
    {
        return 0;
    }
};
employee::employee()
{
    cout << "default constructor" << endl;
    id=0;
}
employee::employee(int i)
{
    cout << "parameterized constructor" << endl;
    id=i;
}
void employee::display()
{
    cout << "id of an employee is" << endl;
    
}
class waggemployee : public employee
{
    int hr, rate;
    public:
    waggemployee();
    waggemployee(int, int, int);
    void display();
    int salary();
};
waggemployee::waggemployee()
{
    cout << "default constructor" << endl;
    hr = 0;
    rate = 0;
}
waggemployee::waggemployee(int h, int r, int i):employee(i)
{
    cout << "default constructor" << endl;
    hr = h;
    rate = r;
}
int waggemployee::salary()
{
    return hr * rate;
}

void waggemployee::display()
{
    waggemployee::display();
    cout << hr << endl;
    cout << rate << endl;
}

int main()
{
     employee * ptr;
	 waggemployee we1(11,5,500);
	 ptr=&we1;
	cout<<"salary is "<<ptr->salary();
	ptr->display();
}