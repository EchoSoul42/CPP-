#include<iostream>
using namespace std;

int main(){
  int a[5]={3,5,7,8,1};
  int i,j,min,temp;
  for (i = 0; i < 4 ; i++)
  {
   min=i;
   for ( j = i+1 ; j < 5; j++)
   { 
    if (a[min]>a[j])
    {
        min=j;
    }
   }
   temp=a[i];
   a[i]=a[min];
   a[min]=temp;
   
  }
  for ( i = 0; i < 5; i++)
  {
    cout<<a[i];
  }
  
  
}


	

