#include<iostream>
using namespace std;

class temp{

    int *ptr;
    int size;
    public: 
    temp();
    void get();
    void show();
    int min();
    int max();


};
temp::temp(){
    cout<<"element stored";
    cin>>size;
    ptr=new int(size);
}
void temp:: get(){
    cout<<"accept the element:";
    for(int i=0;i<size;i++){
        cin>>ptr[i];
    }
}

int temp::max(){
    int m=ptr[0];
    for(int i=1;i<size;i++){
        if(ptr[i]>m)
            m=ptr[i];
            
        
    }
    cout<<"max"<<m;

}

int temp::min(){

    int m=ptr[0];
    for(int i=1;i<size;i++){
        if(ptr[i]<m)
            m=ptr[i];
        
    }
cout<<"min"<<m;

}
    
    


int main(){
    temp a;
    a.get();
    a.max();
    a.min();
    



}

