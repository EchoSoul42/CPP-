#include<iostream>
using namespace std;
class student{
       int rollno;
       char name[20];
       public:
       void accept(){
        cin>>rollno;
        cin>>name;
       }
       void display(){
        cout<<rollno<<endl;
        cout<<name<<endl;
       }
       ~student(){
        cout<<" distructor called"<<endl;
       }
};
int main(){
    int n,i;
    cout<<"enter no of student"<<endl;
    cin>>n;
    student* ptr =new student[n];
    cout<<"Enter Details Roll no and Name"<<endl;
    for ( i = 0; i < n; i++)
    {
        
       (ptr+i)->accept();
    }
    
     cout<<"Details Of Student Are"<<endl;
    for ( i = 0; i < n; i++)
    {  
       ptr[i].display();
    }
    delete[] ptr;
    
}