#include <iostream>
using namespace std;

class Area   //////error
{
private:
    float radius, pii = 3.14;

public:
    float Area_comp()
    {
        float area_1 = pii * radius * radius;    
    }
};

int main()
{
    int  radius = 10;
    Area a;
    cout<<"area ="<<a.Area_comp();
}

// error 
// we cant modifyprivate class member




// #include<iostream>
// using namespace std;
 
// class Circle
// {   
//     // private data member
//     private: 
//         double radius;
      
//     // public member function    
//     public:    
        // double  compute_area()
        // {   // member function can access private 
        //     // data member radius
        //     return 3.14*radius*radius;
        // }
     
//};
 
// // main function
// int main()
// {   
//     // creating object of the class
//     Circle obj;
     
//     // trying to access private data member
//     // directly outside the class
//     obj.radius = 1.5;
     
//     cout << "Area is:" << obj.compute_area();
//     return 0;
// }