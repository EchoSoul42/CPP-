#include<iostream>
using namespace std;

class area{
public:
 float r;
 float area_comp()
 {
    return 3.14*r*r;
 }
};
int main()
{
   area a;
   a.r=11;
   cout<<"area"<<a.area_comp();
   
    }

   
