#include <iostream>
using namespace std;

class area
{
protected:
    float radius;
};
class child : public area
{
public:
    child(float r)
    {
        radius = r;
        float area = 3.14 * radius * radius;
        cout << "area = " << area;
    }
};

int main()
{
    child(11);

   
};